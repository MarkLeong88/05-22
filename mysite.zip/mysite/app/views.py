from django.shortcuts import render_to_response
# Create your views here.
from .models import Restaurant, Food, Introduction

def index(request):
	restaurants = Restaurant.objects.all()
	introduction = Introduction.objects.all()
	return render_to_response('app/menu.html',locals())

# Create your views here.
